import buildnumber

buildnumber.main()
